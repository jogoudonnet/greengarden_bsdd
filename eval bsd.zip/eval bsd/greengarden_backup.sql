-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           10.4.22-MariaDB - Source distribution
-- SE du serveur:                Linux
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Listage des données de la table GreenGarden.appartient : ~0 rows (environ)
/*!40000 ALTER TABLE `appartient` DISABLE KEYS */;
INSERT INTO `appartient` (`ref_produit`, `categorie_prod`) VALUES
	(19, 'horticulture');
/*!40000 ALTER TABLE `appartient` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.categorie_produits : ~3 rows (environ)
/*!40000 ALTER TABLE `categorie_produits` DISABLE KEYS */;
INSERT INTO `categorie_produits` (`categorie_prod`, `sous_categorie`, `categorie_prod_1`) VALUES
	('horticulture', 'jardinage', NULL),
	('jardinage', 'terre', NULL),
	('outillage', 'outils a mains', NULL);
/*!40000 ALTER TABLE `categorie_produits` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.clients : ~20 rows (environ)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` (`id_client`, `nom_client`, `prenom_client`, `email_client`, `num_tel_client`, `adresse_client`, `pro`, `coef_client`, `newsletter`, `id_commercial`) VALUES
	(1, 'jean', 'culé', 'jean@cule.fr', 745362839, '30 rue de la porte', 1, 1.00, 1, 1),
	(2, 'bernard', 'bianca', 'beber@bianca.fr', 749362839, '30 rue de la pourte', 1, 1.00, 1, 1),
	(3, 'josé', 'sandrap', 'jose@sandrap.fr', 749369839, '31 rue de la pelle', 1, 1.00, 1, 1),
	(4, 'tanguy', 'delahorde', 'roxxor@9999.fr', 749319839, '1337 avenue des bilous', 1, 1.00, 1, 1),
	(5, 'jak', 'devo', 'jak@2veaux.fr', 749619839, '0 impasse des titans', 1, 1.00, 1, 1),
	(6, 'simonette', 'xu', 'xuhot@simonette.fr', 749619389, '1 chemin de la chaleur', 1, 1.00, 1, 1),
	(7, 'jacqueline', 'letank', 'armure@1955.fr', 722619389, '1 rue de la moustache', 1, 1.00, 1, 1),
	(8, 'josette', 'latranche', 'pain@dtc.fr', 722619300, '123 rue des grilles pains', 1, 1.00, 1, 1),
	(9, 'fili', 'pine', 'free@massage.fr', 722329300, '13 rue de la la', 0, 0.00, 0, 1),
	(10, 'kevina', 'jse', 'jse@kevina.fr', 799329300, '13 rue de la fierté', 0, 0.00, 0, 1),
	(11, 'marcelle', 'smith', 'un@deux.fr', 799329388, '13 rue de la pomme', 0, 0.00, 0, 2),
	(12, 'teddy', 'smith', 'tro@b1.fr', 799329658, '77 rue du rouleau', 0, 0.00, 0, 2),
	(13, 'agent', 'smith', 'matrix1@bclemeilleur', 239329658, '666 impasse des agents', 0, 0.00, 0, 2),
	(14, 'compresseur', 'pneu', 'gonfle@moi.fr', 238829658, '908 rue de ma pompe', 0, 0.00, 0, 2),
	(15, 'santa', 'clef', 'tupeuxpas@rentrer.fr', 238829611, '11 rue de la blague', 0, 0.00, 0, 2),
	(16, 'momo', 'jante', 'momo@leroiduvelo.fr', 231129611, '78 avenue des cyclistes', 0, 0.00, 0, 2),
	(17, 'sophie', 'métou', 'sophie@métou.fr', 931129611, '78 avenue des bas', 0, 0.00, 0, 2),
	(18, 'petite', 'anne', 'petite-anne@nique.fr', 998712611, '22 avenue bateaux', 0, 0.00, 0, 2),
	(19, 'greg', 'lenormand', 'noraml-dddd@bab.fr', 998732611, '22 avenue sloup', 0, 0.00, 0, 2),
	(20, 'bloop', 'betty', 'jmlagymd@ctrob1.fr', 118832611, '2 avenue calamars', 0, 0.00, 0, 2);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.commande : ~0 rows (environ)
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;
INSERT INTO `commande` (`id_commande`, `date_commande`, `etat_commande`, `total_HT`, `adresse_livraison`, `adresse_facturation`, `negociation`, `paiement_validé`, `id_client`) VALUES
	(1, '2022-03-10', 1, 99.00, '30 rue des bayc', '30 rue des bayc', 10.0, 0, 2),
	(2, '2022-03-14', 1, 790.00, '10 impasse des chats\r\n', '10 impasse des chats', 0.0, 0, 7);
/*!40000 ALTER TABLE `commande` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.commercial : ~5 rows (environ)
/*!40000 ALTER TABLE `commercial` DISABLE KEYS */;
INSERT INTO `commercial` (`id_commercial`, `nom_commercial`, `prenom_commercial`) VALUES
	(1, 'Tatum Rietveld', 'diego'),
	(2, 'Brock Bouwmeester', NULL),
	(3, 'Geraldine Peeters', NULL),
	(4, 'Irma Boivin', NULL),
	(5, 'Blake Dumont', NULL);
/*!40000 ALTER TABLE `commercial` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.contient : ~1 rows (environ)
/*!40000 ALTER TABLE `contient` DISABLE KEYS */;
INSERT INTO `contient` (`ref_produit`, `id_commande`) VALUES
	(2, 1),
	(9, 1);
/*!40000 ALTER TABLE `contient` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.facture : ~0 rows (environ)
/*!40000 ALTER TABLE `facture` DISABLE KEYS */;
INSERT INTO `facture` (`id_facture`, `date_facturation`, `edition_facure`, `id_client`, `id_commande`) VALUES
	(1, '2022-03-10', 1, 2, 1);
/*!40000 ALTER TABLE `facture` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.fournisseur : ~6 rows (environ)
/*!40000 ALTER TABLE `fournisseur` DISABLE KEYS */;
INSERT INTO `fournisseur` (`ID_fournisseur`, `nom_fournisseur`) VALUES
	(1, 'alabonnetruelle'),
	(2, 'bestplante'),
	(3, 'arbreetcompagnie'),
	(4, 'outilsland'),
	(5, 'terreaucbo'),
	(6, 'bellesplante77'),
	(7, 'feuillesdejoie');
/*!40000 ALTER TABLE `fournisseur` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.livraison : ~0 rows (environ)
/*!40000 ALTER TABLE `livraison` DISABLE KEYS */;
INSERT INTO `livraison` (`livraison_id`, `date_livraison`, `edition_bon_liv`, `id_client`, `id_commande`) VALUES
	(1, '2022-03-10', 0, 2, 1);
/*!40000 ALTER TABLE `livraison` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.produits : ~17 rows (environ)
/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
INSERT INTO `produits` (`ref_produit`, `nom_commercial`, `ref_fournisseur`, `prix_achat`, `path_image_produit`, `stock`) VALUES
	(1, 'tronconneuse magique', 'Tm6677', 78, '/images/outillage/tronconneuse-electrique-rcs1935b2c-1558579-1.jpg', 10),
	(2, 'balai a main', 'Btttt78', 7, '/images/outillage/outils-wolf-petit-balai-a-main-a-dents-rondes-multi-star-574364-1.jpg', 43),
	(3, 'taille-haies-electrique', 'th7687', 44, '/images/outillage/taille-haies-electrique-rht5150-1479011-1.jpg', 13),
	(4, 'gants jardinage', 'gjjjdu27', 2, '/images/outillage/gant-enfant-taille-6-8-ans-jd258b-1462800-1.jpg', 112),
	(5, 'coupe bordures electrique', 'gjzsdqa87', 29, '/images/outillage/coupe-bordures-electrique-rlt3525-robin-1479018-1.jpg', 33),
	(6, 'bottes blackfox', 'bt55klp', 4, '/images/outillage/blackfox-botte-phoenix-noir-taille-40-2002599-1.jpg', 98),
	(7, 'jardiniére grise', 'sdgf88', 11, '/images/jardinage/jardiniere-clay-fibre-grise-l-60-x-h-30-cm-874044-1.jpg', 38),
	(9, 'bac cajou', 'rdfgts231', 81, '/images/jardinage/bac-cajou-avec-treillis-arc-l-80-x-l-40-x-h-120-cm-571729-2.jpg', 3),
	(10, 'pot rond blanc', 'edqzt2341', 9, '/images/jardinage/pot-fibre-de-pierre-rond-blanc-54-x-57-1432528-2.jpg', 11),
	(11, 'copeaux gris ardoise', 'uesdfhg6879', 4, '/images/jardinage/terre/jardiland-copeaux-gris-ardoise-50-l-1615468-1.jpg', 41),
	(12, 'terreau universel', 'uesret79', 3, '/images/jardinage/terre/jardiland-terreau-universel-80-l-1444470-1.jpg', 431),
	(13, 'terreau horticole', 'u7HJt79', 3, '/images/jardinage/terre/terreau-horticole-70-l-578020-1.jpg', 931),
	(14, 'pot papatte', 'sfd88ded', 9, '/images/jardinage/pot-g17b49b38e_640.jpg', 91),
	(15, 'roses, a la folie', 'ros68909', 3, '/images/fleurs/a-la-folie-350x350-41984.jpg', 112),
	(16, 'dendrobium-nobile', 'denbb32', 3, '/images/fleurs/dendrobium-nobile-350x350-36356.jpg', 90),
	(17, 'orchidee papillon', 'orch23kki', 3, '/images/fleurs/orchidee-papillon-350x350-38100.jpg', 910),
	(18, 'roses et gourmandise', 'ros8UN22', 6, '/images/fleurs/roses-et-gourmandise-350x350-42418.jpg', 190),
	(19, 'anemones francaises', 'anem9Hx', 6, '/images/fleurs/bouquet/anemones-francaises-350x350-35004.jpg', 10),
	(20, 'bouquet de roses blanches', 'bqrsb22', 7, '/images/fleurs/bouquet/bouquet-de-roses-blanches-livraison-de-roses-350x350-39505.jpg', 120),
	(21, 'bouquet parfume', 'bqpar682dd', 7, '/images/fleurs/bouquet/bouquet-parfume-350x350-38034.jpg', 1);
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;

-- Listage des données de la table GreenGarden.provient : ~0 rows (environ)
/*!40000 ALTER TABLE `provient` DISABLE KEYS */;
INSERT INTO `provient` (`ref_produit`, `ID_fournisseur`) VALUES
	(9, 2);
/*!40000 ALTER TABLE `provient` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
