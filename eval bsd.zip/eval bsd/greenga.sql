-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 15 mars 2022 à 15:31
-- Version du serveur : 10.4.22-MariaDB
-- Version de PHP : 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `greenga`
--

-- --------------------------------------------------------

--
-- Structure de la table `appartient`
--

CREATE TABLE `appartient` (
  `ref_produit` int(11) NOT NULL,
  `categorie_prod` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `categorie_produits`
--

CREATE TABLE `categorie_produits` (
  `categorie_prod` varchar(50) NOT NULL,
  `sous_categorie` varchar(50) DEFAULT NULL,
  `categorie_prod_1` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `categorie_produits`
--

INSERT INTO `categorie_produits` (`categorie_prod`, `sous_categorie`, `categorie_prod_1`) VALUES
('horticulture', 'rose', NULL),
('jardinage', 'pots', NULL),
('outillage', 'a mains', NULL),
('reyeh', 'rhef', 'reyeh');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `id_client` int(11) NOT NULL,
  `nom_client` varchar(20) DEFAULT NULL,
  `prenom_client` varchar(20) DEFAULT NULL,
  `email_client` varchar(30) DEFAULT NULL,
  `num_tel_client` int(11) DEFAULT NULL,
  `adresse_client` varchar(50) DEFAULT NULL,
  `pro` tinyint(1) DEFAULT NULL,
  `coef_client` decimal(4,2) DEFAULT NULL,
  `newsletter` tinyint(1) DEFAULT NULL,
  `id_commercial` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id_client`, `nom_client`, `prenom_client`, `email_client`, `num_tel_client`, `adresse_client`, `pro`, `coef_client`, `newsletter`, `id_commercial`) VALUES
(1, 'cule', 'jean', 'jean_cule@wanadoo.fr', 765443322, '22 rue de laojws', 0, '0.00', 1, 1),
(2, 'bernard', 'bianca', 'beber@bianca.fr', 749362839, '30 rue de la pourte', 1, '1.00', 1, 1),
(3, 'josé', 'sandrap', 'jose@sandrap.fr', 749369839, '31 rue de la pelle', 1, '1.00', 1, 1),
(4, 'tanguy', 'delahorde', 'roxxor@9999.fr', 749319839, '1337 avenue des bilous', 1, '1.00', 1, 1),
(5, 'jak', 'devo', 'jak@2veaux.fr', 749619839, '0 impasse des titans', 1, '1.00', 1, 1),
(6, 'simonette', 'xu', 'xuhot@simonette.fr', 749619389, '1 chemin de la chaleur', 1, '1.00', 1, 1),
(7, 'jacqueline', 'letank', 'armure@1955.fr', 722619389, '1 rue de la moustache', 1, '1.00', 1, 1),
(8, 'josette', 'latranche', 'pain@dtc.fr', 722619300, '123 rue des grilles pains', 1, '1.00', 1, 1),
(9, 'fili', 'pine', 'free@massage.fr', 722329300, '13 rue de la la', 0, '0.00', 0, 1),
(10, 'kevina', 'jse', 'jse@kevina.fr', 799329300, '13 rue de la fierté', 0, '0.00', 0, 1),
(11, 'marcelle', 'smith', 'un@deux.fr', 799329388, '13 rue de la pomme', 0, '0.00', 0, 2),
(12, 'teddy', 'smith', 'tro@b1.fr', 799329658, '77 rue du rouleau', 0, '0.00', 0, 2),
(13, 'agent', 'smith', 'matrix1@bclemeilleur', 239329658, '666 impasse des agents', 0, '0.00', 0, 2),
(14, 'compresseur', 'pneu', 'gonfle@moi.fr', 238829658, '908 rue de ma pompe', 0, '0.00', 0, 2),
(15, 'santa', 'clef', 'tupeuxpas@rentrer.fr', 238829611, '11 rue de la blague', 0, '0.00', 0, 2),
(16, 'momo', 'jante', 'momo@leroiduvelo.fr', 231129611, '78 avenue des cyclistes', 0, '0.00', 0, 2),
(17, 'sophie', 'métou', 'sophie@métou.fr', 931129611, '78 avenue des bas', 0, '0.00', 0, 2),
(18, 'petite', 'anne', 'petite-anne@nique.fr', 998712611, '22 avenue bateaux', 0, '0.00', 0, 2),
(19, 'greg', 'lenormand', 'noraml-dddd@bab.fr', 998732611, '22 avenue sloup', 0, '0.00', 0, 2),
(20, 'bloop', 'betty', 'jmlagymd@ctrob1.fr', 118832611, '2 avenue calamars', 0, '0.00', 0, 2);

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL,
  `date_commande` date DEFAULT NULL,
  `etat_commande` int(11) DEFAULT NULL,
  `total_HT` decimal(8,2) DEFAULT NULL,
  `adresse_livraison` varchar(50) DEFAULT NULL,
  `adresse_facturation` varchar(50) DEFAULT NULL,
  `negociation` decimal(3,1) DEFAULT NULL,
  `paiement_validé` tinyint(1) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `date_commande`, `etat_commande`, `total_HT`, `adresse_livraison`, `adresse_facturation`, `negociation`, `paiement_validé`, `id_client`) VALUES
(1, '2022-02-25', 1, NULL, '12 rue dde ut', '12 rue dde ut', '0.0', 0, 1);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `commande_client`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `commande_client` (
`id_client` int(11)
,`pro` tinyint(1)
,`id_commande` int(11)
,`date_commande` date
,`total_HT` decimal(8,2)
,`paiement_validé` tinyint(1)
);

-- --------------------------------------------------------

--
-- Structure de la table `commercial`
--

CREATE TABLE `commercial` (
  `id_commercial` int(11) NOT NULL,
  `nom_commercial` varchar(20) DEFAULT NULL,
  `prenom_commercial` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `commercial`
--

INSERT INTO `commercial` (`id_commercial`, `nom_commercial`, `prenom_commercial`) VALUES
(1, 'Tatum Rietveld', 'diego'),
(2, 'Brock Bouwmeester', NULL),
(3, 'Geraldine Peeters', NULL),
(4, 'Irma Boivin', NULL),
(5, 'Blake Dumont', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `contient`
--

CREATE TABLE `contient` (
  `ref_produit` int(11) NOT NULL,
  `id_commande` int(11) NOT NULL,
  `quantite` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `contient`
--

INSERT INTO `contient` (`ref_produit`, `id_commande`, `quantite`) VALUES
(1, 1, 1),
(2, 1, 1),
(5, 1, 1),
(17, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `facture` (
  `id_facture` varchar(50) NOT NULL,
  `date_facturation` date DEFAULT NULL,
  `edition_facure` tinyint(1) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `id_commande` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `fournisseeur_produits`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `fournisseeur_produits` (
`ref_produit` int(11)
,`nom_commercial` varchar(40)
,`ref_fournisseur` varchar(11)
,`prix_achat` int(11)
,`path_image_produit` varchar(500)
,`stock` int(11)
,`ID_fournisseur` int(11)
,`nom_fournisseur` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

CREATE TABLE `fournisseur` (
  `ID_fournisseur` int(11) NOT NULL,
  `nom_fournisseur` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `fournisseur`
--

INSERT INTO `fournisseur` (`ID_fournisseur`, `nom_fournisseur`) VALUES
(1, 'alabonnetruelle'),
(2, 'bestplante'),
(3, 'arbreetcompagnie'),
(4, 'outilsland'),
(5, 'terreaucbo'),
(6, 'bellesplante77'),
(7, 'feuillesdejoie');

-- --------------------------------------------------------

--
-- Structure de la table `livraison`
--

CREATE TABLE `livraison` (
  `livraison_id` int(11) NOT NULL,
  `date_livraison` date DEFAULT NULL,
  `edition_bon_liv` tinyint(1) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `id_commande` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `livraison`
--

INSERT INTO `livraison` (`livraison_id`, `date_livraison`, `edition_bon_liv`, `id_client`, `id_commande`) VALUES
(1, '2022-03-15', 0, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `ref_produit` int(11) NOT NULL,
  `nom_commercial` varchar(40) DEFAULT NULL,
  `ref_fournisseur` varchar(11) DEFAULT NULL,
  `prix_achat` int(11) DEFAULT NULL,
  `path_image_produit` varchar(500) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`ref_produit`, `nom_commercial`, `ref_fournisseur`, `prix_achat`, `path_image_produit`, `stock`) VALUES
(1, 'tronconneuse magic', 'edqzstfgr', 78, NULL, 9),
(2, 'rose rouge', 'ldsfih', 2, NULL, 978),
(3, 'taille-haies-electrique', 'th7687', 44, '/images/outillage/taille-haies-electrique-rht5150-1479011-1.jpg', 13),
(4, 'gants jardinage', 'gjjjdu27', 2, '/images/outillage/gant-enfant-taille-6-8-ans-jd258b-1462800-1.jpg', 112),
(5, 'coupe bordures electrique', 'gjzsdqa87', 29, '/images/outillage/coupe-bordures-electrique-rlt3525-robin-1479018-1.jpg', 33),
(6, 'bottes blackfox', 'bt55klp', 4, '/images/outillage/blackfox-botte-phoenix-noir-taille-40-2002599-1.jpg', 98),
(7, 'jardiniére grise', 'sdgf88', 11, '/images/jardinage/jardiniere-clay-fibre-grise-l-60-x-h-30-cm-874044-1.jpg', 38),
(9, 'bac cajou', 'rdfgts231', 81, '/images/jardinage/bac-cajou-avec-treillis-arc-l-80-x-l-40-x-h-120-cm-571729-2.jpg', 3),
(10, 'pot rond blanc', 'edqzt2341', 9, '/images/jardinage/pot-fibre-de-pierre-rond-blanc-54-x-57-1432528-2.jpg', 11),
(11, 'copeaux gris ardoise', 'uesdfhg6879', 4, '/images/jardinage/terre/jardiland-copeaux-gris-ardoise-50-l-1615468-1.jpg', 41),
(12, 'terreau universel', 'uesret79', 3, '/images/jardinage/terre/jardiland-terreau-universel-80-l-1444470-1.jpg', 431),
(13, 'terreau horticole', 'u7HJt79', 3, '/images/jardinage/terre/terreau-horticole-70-l-578020-1.jpg', 931),
(14, 'pot papatte', 'sfd88ded', 9, '/images/jardinage/pot-g17b49b38e_640.jpg', 91),
(15, 'roses, a la folie', 'ros68909', 3, '/images/fleurs/a-la-folie-350x350-41984.jpg', 112),
(16, 'dendrobium-nobile', 'denbb32', 3, '/images/fleurs/dendrobium-nobile-350x350-36356.jpg', 90),
(17, 'orchidee papillon', 'orch23kki', 3, '/images/fleurs/orchidee-papillon-350x350-38100.jpg', 910),
(18, 'roses et gourmandise', 'ros8UN22', 6, '/images/fleurs/roses-et-gourmandise-350x350-42418.jpg', 190),
(19, 'anemones francaises', 'anem9Hx', 6, '/images/fleurs/bouquet/anemones-francaises-350x350-35004.jpg', 10),
(20, 'bouquet de roses blanches', 'bqrsb22', 7, '/images/fleurs/bouquet/bouquet-de-roses-blanches-livraison-de-roses-350x350-39505.jpg', 120),
(21, 'bouquet parfume', 'bqpar682dd', 7, '/images/fleurs/bouquet/bouquet-parfume-350x350-38034.jpg', 1);

-- --------------------------------------------------------

--
-- Structure de la table `provient`
--

CREATE TABLE `provient` (
  `ref_produit` int(250) NOT NULL,
  `ID_fournisseur` int(11) NOT NULL,
  `quantité` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `provient`
--

INSERT INTO `provient` (`ref_produit`, `ID_fournisseur`, `quantité`) VALUES
(1, 1, 10),
(6, 1, 81),
(17, 1, 123),
(20, 1, 34);

-- --------------------------------------------------------

--
-- Structure de la vue `commande_client`
--
DROP TABLE IF EXISTS `commande_client`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `commande_client`  AS SELECT `clients`.`id_client` AS `id_client`, `clients`.`pro` AS `pro`, `commande`.`id_commande` AS `id_commande`, `commande`.`date_commande` AS `date_commande`, `commande`.`total_HT` AS `total_HT`, `commande`.`paiement_validé` AS `paiement_validé` FROM (`clients` join `commande`) ;

-- --------------------------------------------------------

--
-- Structure de la vue `fournisseeur_produits`
--
DROP TABLE IF EXISTS `fournisseeur_produits`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fournisseeur_produits`  AS SELECT `produits`.`ref_produit` AS `ref_produit`, `produits`.`nom_commercial` AS `nom_commercial`, `produits`.`ref_fournisseur` AS `ref_fournisseur`, `produits`.`prix_achat` AS `prix_achat`, `produits`.`path_image_produit` AS `path_image_produit`, `produits`.`stock` AS `stock`, `fournisseur`.`ID_fournisseur` AS `ID_fournisseur`, `fournisseur`.`nom_fournisseur` AS `nom_fournisseur` FROM (`produits` join `fournisseur`) ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `appartient`
--
ALTER TABLE `appartient`
  ADD PRIMARY KEY (`ref_produit`,`categorie_prod`),
  ADD KEY `categorie_prod` (`categorie_prod`);

--
-- Index pour la table `categorie_produits`
--
ALTER TABLE `categorie_produits`
  ADD PRIMARY KEY (`categorie_prod`),
  ADD KEY `categorie_prod_1` (`categorie_prod_1`);

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id_client`),
  ADD KEY `id_commercial` (`id_commercial`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `id_client` (`id_client`);

--
-- Index pour la table `commercial`
--
ALTER TABLE `commercial`
  ADD PRIMARY KEY (`id_commercial`);

--
-- Index pour la table `contient`
--
ALTER TABLE `contient`
  ADD PRIMARY KEY (`ref_produit`,`id_commande`),
  ADD KEY `id_commande` (`id_commande`);

--
-- Index pour la table `facture`
--
ALTER TABLE `facture`
  ADD PRIMARY KEY (`id_facture`),
  ADD KEY `id_client` (`id_client`),
  ADD KEY `id_commande` (`id_commande`);

--
-- Index pour la table `fournisseur`
--
ALTER TABLE `fournisseur`
  ADD PRIMARY KEY (`ID_fournisseur`);

--
-- Index pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD PRIMARY KEY (`livraison_id`),
  ADD KEY `id_client` (`id_client`),
  ADD KEY `id_commande` (`id_commande`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`ref_produit`);

--
-- Index pour la table `provient`
--
ALTER TABLE `provient`
  ADD PRIMARY KEY (`ref_produit`,`ID_fournisseur`),
  ADD KEY `ID_fournisseur` (`ID_fournisseur`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `appartient`
--
ALTER TABLE `appartient`
  ADD CONSTRAINT `appartient_ibfk_1` FOREIGN KEY (`ref_produit`) REFERENCES `produits` (`ref_produit`),
  ADD CONSTRAINT `appartient_ibfk_2` FOREIGN KEY (`categorie_prod`) REFERENCES `categorie_produits` (`categorie_prod`);

--
-- Contraintes pour la table `categorie_produits`
--
ALTER TABLE `categorie_produits`
  ADD CONSTRAINT `categorie_produits_ibfk_1` FOREIGN KEY (`categorie_prod_1`) REFERENCES `categorie_produits` (`categorie_prod`);

--
-- Contraintes pour la table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`id_commercial`) REFERENCES `commercial` (`id_commercial`);

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`);

--
-- Contraintes pour la table `contient`
--
ALTER TABLE `contient`
  ADD CONSTRAINT `contient_ibfk_1` FOREIGN KEY (`ref_produit`) REFERENCES `produits` (`ref_produit`),
  ADD CONSTRAINT `contient_ibfk_2` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`);

--
-- Contraintes pour la table `facture`
--
ALTER TABLE `facture`
  ADD CONSTRAINT `facture_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`),
  ADD CONSTRAINT `facture_ibfk_2` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`);

--
-- Contraintes pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD CONSTRAINT `livraison_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`),
  ADD CONSTRAINT `livraison_ibfk_2` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`);

--
-- Contraintes pour la table `provient`
--
ALTER TABLE `provient`
  ADD CONSTRAINT `provient_ibfk_1` FOREIGN KEY (`ref_produit`) REFERENCES `produits` (`ref_produit`),
  ADD CONSTRAINT `provient_ibfk_2` FOREIGN KEY (`ID_fournisseur`) REFERENCES `fournisseur` (`ID_fournisseur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
